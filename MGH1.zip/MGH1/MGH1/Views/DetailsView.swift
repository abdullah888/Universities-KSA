//
//  DetailsView.swift
//  MGH1
//
//  Created by abdullah FH on 24/08/1446 AH.
//

import SwiftUI
import SDWebImageSwiftUI
import Firebase


struct DetailsView: View {
    @State private var isLoading = false
    @State var showpdf = false
    var product: ProductModel
    @State private var counter = 1
    @Environment(\.presentationMode) var presentationMode
    @State var color = Color("Color")
    var body: some View {
        VStack{
        List {
            VStack(alignment: .leading, spacing: 16) {
                HStack{
                    Spacer()
                    // Product Image
                    WebImage(url: URL(string: product.ProductImage!)!)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(maxWidth: .infinity,maxHeight: .infinity)
                        .cornerRadius(20)
                        .shadow(radius: 5)
                }
                HStack{
                    Spacer()
                    // Product Title
                    Text(product.ProductName!)
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(color)
                }
                // Divider
                Divider()
                    .foregroundColor(color)
                HStack{
                    Spacer()
//                    Stepper("\(counter)", value:$counter, in: 1...5)
//                        .frame(width: 140)
//                        .tint(Color(color))
//                        .foregroundColor(color)
                    Text("المراجع المتوفرة (pdf) :")
                        .fontWeight(.bold)
                        .foregroundColor(color)
                }
                VStack(alignment: .leading, spacing: 8){
                    HStack{
                Spacer(minLength: 0)
                        // Product Description
                        HStack{
                            
                        // Product Price
    //                    Text("$\(String(format: "%.2f", product.ProductPrice!))")
                            Text(calculateproductTotalPrice())
                                .font(.caption)
                                .foregroundColor(.green)
                            Spacer(minLength: 0)
                            Text(product.ProductDetails!)
                                .font(.body)
                                .multilineTextAlignment(.trailing)
                                .foregroundColor(color)
                        }.padding()
                    }
                    HStack{
                        Spacer()
                          if product.ProductURL!.isEmpty {
                              Text("لا يوجد ملفات")
                                  } else {
                                      Text(isLoading ? "يتم التحميل ..." : "تحميل")
                                          .font(.caption)
                                          .foregroundColor(.green)
                                          .onTapGesture {
                                              startDownload()

                                          }
                              }
                        Spacer()
                    }
                }
            }
            .padding()
        }
      
        }.sheet(isPresented: $showpdf) {
            PDFKitView(product: product)
        }
    }
    func calculateproductTotalPrice()->String{
            var price : Float = 0
            price += Float(truncating: counter as NSNumber) * Float(truncating: product.ProductPrice! as NSNumber)
        return getPrice(value: price)
    }
    
    func getPrice(value: Float)->String{
        let format = NumberFormatter()
        format.numberStyle = .currency
        format.currencySymbol = "SR"
        return format.string(from: NSNumber(value: value)) ?? ""
    }
    private func startDownload() {
        isLoading = true
        
        // Simulate a download process
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            // Simulate download completion
            isLoading = false
            showpdf.toggle()
        }
       
    }
//    func Uploada(){
//        let ID = Auth.auth().currentUser?.uid
//        CartModel(ID: UUID().uuidString, UserID: ID!, CartName: product.ProductName!, CartPrice: product.ProductPrice!, CartQuantitiy: counter, CartDetails: product.ProductDetails!, CartImage: product.ProductImage!, CartID: ID!, TotaleCartPrice: calculateproductTotalPrice()).Upload()
//        self.presentationMode.wrappedValue.dismiss()
//    }
//    func addtoCart(){
//        let db = Firestore.firestore()
//        let id = Auth.auth().currentUser?.uid
//        db.collection("Carts")
//            .document()
//            .setData(["UserID":id!,
//                      "CartName":product.ProductName!,
//                      "CartPrice":product.ProductPrice!,
//                      "CartQuantitiy":counter,
//                      "CartDetails":product.ProductDetails!,
//                      "CartImage":product.ProductImage!,
//                      "CartID":id!,
//                      "TotaleCartPrice":calculateproductTotalPrice()
//
//            ]) { (err) in
//
//                if err != nil{
//
//                    print((err?.localizedDescription)!)
//                    return
//                }
//
//                // it will dismiss the recently presented modal....
//
//            }
//        presentationMode.wrappedValue.dismiss()
//        }
//
  
}




struct DownloadButtonView: View {
    @State private var isDownloading = false
    @State private var progress: CGFloat = 0.0

    var body: some View {
        VStack {
            Button(action: {
                startDownload()
            }) {
                HStack {
                    if isDownloading {
                        ProgressView(value: progress, total: 1.0)
                            .progressViewStyle(LinearProgressViewStyle())
                            .frame(width: 100)
                            .padding(.trailing, 5)
                    } else {
                        Image(systemName: "arrow.down.circle.fill")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(.white)
                    }
                    Text(isDownloading ? "Downloading..." : "Download")
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                }
                .padding()
                .background(isDownloading ? Color.gray : Color.blue)
                .cornerRadius(10)
                .scaleEffect(isDownloading ? 0.95 : 1.0)
                .animation(.easeInOut, value: isDownloading)
            }
            .disabled(isDownloading) // Disable button while downloading
        }
        .padding()
    }

    private func startDownload() {
        isDownloading = true
        progress = 0.0
        
        // Simulate a download process
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
            if progress < 1.0 {
                progress += 0.05 // Increment progress
            } else {
                timer.invalidate() // Stop the timer when done
                isDownloading = false // Reset state
            }
        }
    }
}



struct DownloadButtonVieww: View {
    @State private var isLoading = false
    @State var showpdf = false
    var product: ProductModel
    var body: some View {
        
        Button(action: {
          
            startDownload()
        }) {
            if isLoading {
                HStack {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                    Text("Downloading...")
                }
            } else {
                Image(systemName: "arrow.down.circle.fill")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .foregroundColor(.white)
            }

        }
        .buttonStyle(PrimaryButtonStyle())
        .disabled(isLoading) // Disable button while loading
        .padding()
        
        
        
        
    }

    private func startDownload() {
        isLoading = true
        
        // Simulate a download process
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            // Simulate download completion
            isLoading = false
        }
    }
}

struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .background(configuration.isPressed ? Color.gray : Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .animation(.easeInOut(duration: 0.2), value: configuration.isPressed)
    }
}

