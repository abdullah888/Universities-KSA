//
//  CardView.swift
//  MGH1
//
//  Created by abdullah FH on 29/08/1446 AH.
//
import PDFKit
import WebKit
import FirebaseFirestore
import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseStorage
import MobileCoreServices
import SDWebImageSwiftUI

struct CardView: View {
    var product : ProductModel
    @State var color = Color("Color")
    var body: some View {
        VStack {
            WebImage(url: URL(string: product.ProductImage!)!)
                .resizable()
                .scaledToFill()
                .frame(width: 330, height: 500)
                .cornerRadius(20)
                .overlay(
                    Text(product.ProductName!)
                        .font(.system(.headline, design: .rounded))
                        .fontWeight(.heavy)
                        .foregroundStyle(color)
                        .padding(10)
                        .background(.clear)
//                        .background(Color.primary.opacity(0.3))
//                        .cornerRadius(20)
                        .padding([.bottom, .leading])
                        .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .bottomLeading))
        }
    }
}

