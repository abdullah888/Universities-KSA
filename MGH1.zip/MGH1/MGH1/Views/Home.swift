//
//  Home.swift
//  MGH1
//
//  Created by abdullah FH on 18/08/1446 AH.
//
import SwiftUI
import Firebase
import SDWebImageSwiftUI
// عرض الصر في الشاشو الديسية ،عرض الملفات غيد شكلها
struct Home: View {
    @StateObject var ProductData = ProductViewModel()
    var animation: Namespace.ID
    @State var ShowSearch = false
    @State var ShowDetails = false
    @State var color = Color("Color")
    @State var searchText: String = ""
    func Header(title: String) -> HStack<TupleView<(Spacer ,Text)>> {
        return // since both are same so were going to make it as reuable...
            HStack{
                Spacer()
                Text(title)
                    .font(.title)
                    .fontWeight(.heavy)
                    .foregroundColor(color)
                
            }
    }
    var body: some View {
        ScrollView(.vertical) {
            VStack(spacing: 15) {
                Header(title: "المملكة العربية السعودية")
                    .padding()
                
                HStack(spacing: 12) {
                    HStack(spacing: 12) {
                        Image(systemName: "magnifyingglass")
                            .foregroundStyle(color)
                        
                        TextField("", text: $searchText)
                            .multilineTextAlignment(.trailing)
                            .foregroundColor(self.color)
                            .placeholder(when: searchText.isEmpty, placeholder: {
                                HStack{
                                    Text("بحث")
                                    Image(systemName: "magnifyingglass")
                                }.foregroundColor(self.color)
                                    .opacity(0.6)
                               
                            })
                        Image(systemName: "line.3.horizontal.decrease.circle")
                            .font(.title3)
                            .foregroundStyle(color)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 10)
                    .background(.ultraThinMaterial, in: .capsule)
                }

                ScrollView(.horizontal) {
                    HStack(spacing: 5) {
                        ForEach(ProductData.products) { product in
                            NavigationLink(destination: DetailsView(product: product)) {
                                Image("salogos")
                                    .resizable()
                                    .background(Color.white)
                                    .frame(width: 330, height: 500)
                                    .cornerRadius(20)
                                    .overlay {
                                        ZStack(alignment: .bottomTrailing) {
                                            LinearGradient(colors: [.clear, .clear, .clear, .clear, .clear, .black.opacity(0.1), .black.opacity(0.5), .black
                                                                   ], startPoint: .top, endPoint: .bottom)
                                            
                                            VStack(alignment: .trailing, spacing: 4) {
                                                Text(product.ProductName!)
                                                    .font(.headline)
                                                    .fontWeight(.black)
                                                    .foregroundColor(color)
                                                    .multilineTextAlignment(.trailing)
                                                    .font(.callout)
                                                    .foregroundStyle(color.opacity(0.8))
                                            }
                                            .padding()
                                        }.cornerRadius(20)
                                    }
                                }
                            }
                        }
                    }
            }
          
        }
     //   .scrollIndicators(.hidden)
        .onAppear {
            ProductData.fetchData()
        }
       
    }
    
 
}



struct Home2: View {
    @StateObject var ProductData = ProductViewModel()
    var animation: Namespace.ID
    @State var ShowSearch = false
    @State var ShowDetails = false
    @State var color = Color("Color")
    @State var searchText: String = ""
    func Header(title: String) -> HStack<TupleView<(Spacer ,Text)>> {
        return // since both are same so were going to make it as reuable...
            HStack{
                Spacer()
                Text(title)
                    .font(.title)
                    .fontWeight(.heavy)
                    .foregroundColor(color)
                
            }
    }
    var body: some View {
        ScrollView(.vertical) {
            VStack(spacing: 15) {
                Header(title: "المملكة العربية السعودية")
                    .padding()
                
                HStack(spacing: 12) {
                    HStack(spacing: 12) {
                        Image(systemName: "magnifyingglass")
                            .foregroundStyle(color)
                        
                        TextField("", text: $searchText)
                            .multilineTextAlignment(.trailing)
                            .foregroundColor(self.color)
                            .placeholder(when: searchText.isEmpty, placeholder: {
                                HStack{
                                    Text("بحث")
                                    Image(systemName: "magnifyingglass")
                                }.foregroundColor(self.color)
                                    .opacity(0.6)
                               
                            })
                        Image(systemName: "line.3.horizontal.decrease.circle")
                            .font(.title3)
                            .foregroundStyle(color)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 10)
                    .background(.ultraThinMaterial, in: .capsule)
                }
                
                
                GeometryReader { geo in
                    let size = geo.size
                    
                    ScrollView(.horizontal) {
                        HStack(spacing: 5) {
                            ForEach(ProductData.products) { product in
                                GeometryReader { proxy in
                                    let cardSize = proxy.size
                                    
                                    let minX = min((proxy.frame(in: .scrollView).minX - 30) * 1.4, size.width * 1.4)
                                    NavigationLink(destination: DetailsView(product: product)) {
                                        WebImage(url: URL(string: product.ProductImage!)!)
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .offset(x: -minX)
                                            .frame(width: cardSize.width, height: cardSize.height)
                                            .overlay(Isaimation(product))
                                            .clipShape(.rect(cornerRadius: 15))
                                            .shadow(color: .black.opacity(0.25), radius: 8, x: 5, y: 10)
                                    }
                                }
                                .frame(width: size.width - 60, height: size.height - 50)
                                .scrollTransition(.interactive, axis: .horizontal) { view, phase in
                                    view
                                        .scaleEffect(phase.isIdentity ? 1 : 0.95)
                                }
                            }
                        }
                        .padding(.horizontal, 30)
                        .scrollTargetLayout()
                        .frame(height: size.height, alignment: .top)
                    }
                    .scrollTargetBehavior(.viewAligned)
                    .scrollIndicators(.hidden)
                }
                .frame(height: 500)
                .padding(.horizontal, -15)
                .padding(.top, 20)
                
            }
            .padding(15)
        }
        .scrollIndicators(.hidden)
        .onAppear {
            ProductData.fetchData()
        }
    }
    
    @ViewBuilder
    func Isaimation(_ product: ProductModel) -> some View {
        ZStack(alignment: .bottomTrailing) {
            LinearGradient(colors: [.clear, .clear, .clear, .clear, .clear, .black.opacity(0.1), .black.opacity(0.5), .black
            ], startPoint: .top, endPoint: .bottom)
            
            VStack(alignment: .trailing, spacing: 4) {
                Text(product.ProductName!)
                    .font(.title2)
                    .fontWeight(.black)
                    .foregroundColor(color)
                
                Text(product.ProductDetails!)
                    .multilineTextAlignment(.trailing)
                    .font(.callout)
                    .foregroundStyle(color.opacity(0.8))
                
            }
            .padding()
        }
    }
}



