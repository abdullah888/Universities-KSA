//
//  AddProfile.swift
//  Project001app
//
//  Created by abdullah FH on 22/05/1446 AH.
//

import SwiftUI

struct AddProfile: View {
    var body: some View {
        Text("AddProfile")
    }
}

struct AddProfile_Previews: PreviewProvider {
    static var previews: some View {
        AddProfile()
    }
}
