//
//  LogOut.swift
//  MM1
//
//  Created by abdullah FH on 17/08/1446 AH.
//

import SwiftUI
import Firebase
import FirebaseAuth

struct LogOut: View {
    @StateObject var Userdata = ProfileViewModel()
    var body: some View {
        VStack {
            Button {
                try! Auth.auth().signOut()
                UserDefaults.standard.set(false, forKey: "status")
                NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
            } label: {
                Image(systemName: "power")
                    .font(.title)
                    .foregroundColor(.red)
                
            } .padding()
        } .frame(maxWidth: .infinity, maxHeight: .infinity)
            .tag(tabs[2])
            .background(Color("bg").ignoresSafeArea())
    }
}

struct LogOut_Previews: PreviewProvider {
    static var previews: some View {
        LogOut()
    }
}
