//
//  MGH1App.swift
//  MGH1
//
//  Created by abdullah FH on 18/08/1446 AH.
//

import SwiftUI
import FirebaseCore


class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    FirebaseApp.configure()

    return true
  }
}

@main
struct MGH1App: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @State var color = Color("Color")
    var body: some Scene {
        WindowGroup {
            ContentView()
                .accentColor(color)
        }
    }
}
