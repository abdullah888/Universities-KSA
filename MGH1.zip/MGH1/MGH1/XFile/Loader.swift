//
//  Loader.swift
//  Project001app
//
//  Created by abdullah FH on 18/06/1446 AH.
//

import SwiftUI
import Firebase
import SDWebImageSwiftUI


struct Loader: View {
    var body: some View {
        Group {
            ProgressView("Loading…")
                .progressViewStyle(CircularProgressViewStyle(tint: Color.black))
        }
        .padding()
        .background(Color.black.opacity(0.1))
        .cornerRadius(10)
    }
}

