//
//  UserModel.swift
//  MM1
//
//  Created by abdullah FH on 17/08/1446 AH.
//

import SwiftUI
import Foundation
import Firebase

class UserModel :Identifiable {
    
    var ID : String?
    var Name : String?
    var Phonenumber : String?
    var Image : String?
    
    init(ID : String ,  Name : String,Phonenumber : String, Image : String) {
        self.ID = ID
        self.Name = Name
        self.Phonenumber = Phonenumber
        self.Image = Image
      
    }
    
    init(Dictionary : [String : AnyObject]) {
        self.ID = Dictionary["ID"] as? String
        self.Name = Dictionary["Name"] as? String
        self.Phonenumber = Dictionary["Phonenumber"] as? String
        self.Image = Dictionary["Image"] as? String
    }
    
    func MakeDictionary()->[String : AnyObject] {
        var New : [String : AnyObject] = [:]
        New["ID"] = self.ID as AnyObject
        New["Name"] = self.Name as AnyObject
        New["Phonenumber"] = self.Phonenumber as AnyObject
        New["Image"] = self.Image as AnyObject
        return New
    }
    
    func Upload(){
        guard let id = self.ID else { return }
        Firestore.firestore().collection("Users").document(id).setData(MakeDictionary())
    }
    
//    func Remove(){
//        guard let id = self.ID else { return }
//        Firestore.firestore().collection("Users").document(id).delete()
//    }
    
    
    
    
}


class UserApi {
    
    
    static func GetUser(ID : String, completion : @escaping (_ User : UserModel)->()){
        
        Firestore.firestore().collection("Users").document(ID).addSnapshotListener { (Snapshot : DocumentSnapshot?, Error : Error?) in
            
            if let data = Snapshot?.data() as [String : AnyObject]? {
               let New = UserModel(Dictionary: data)
                completion(New)
            }
            
        }
        
    }
    
    static func GetAllUsers(completion : @escaping (_ User : UserModel)->()){
        Firestore.firestore().collection("Users").getDocuments { (Snapshot, error) in
            if error != nil { print("Error") ; return }
            guard let documents = Snapshot?.documents else { return }
            for P in documents {
                if let data = P.data() as [String : AnyObject]? {
                    let New = UserModel(Dictionary: data)
                    completion(New)
                }
            }
        }

    }

    
    
}
