//
//  ProducttModel.swift
//  MM1
//
//  Created by abdullah FH on 17/08/1446 AH.
//

import SwiftUI
import Foundation
import Firebase

class ProductModel :Identifiable,ObservableObject {
    
  
    var ID : String?
    var ProductName : String?
    var ProductPrice : Double?
    var ProductQuantitiy : Int?
    var ProductDetails: String?
    var ProductImage : String?
    var ProductURL : String?
    
    init(ID : String ,  ProductName : String, ProductPrice : Double, ProductQuantitiy : Int, ProductDetails: String, ProductImage : String , ProductURL : String) {
        self.ID = ID
        self.ProductName = ProductName
        self.ProductPrice = ProductPrice
        self.ProductQuantitiy = ProductQuantitiy
        self.ProductDetails = ProductDetails
        self.ProductImage = ProductImage
        self.ProductURL = ProductURL
    }
    
    init(Dictionary : [String : AnyObject]) {
        self.ID = Dictionary["ID"] as? String
        self.ProductName = Dictionary["ProductName"] as? String
        self.ProductPrice = Dictionary["ProductPrice"] as? Double
        self.ProductQuantitiy = Dictionary["ProductQuantitiy"] as? Int
        self.ProductDetails = Dictionary["ProductDetails"] as? String
        self.ProductImage = Dictionary["ProductImage"] as? String
        self.ProductURL = Dictionary["ProductURL"] as? String
    }
    
    func MakeDictionary()->[String : AnyObject] {
        var New : [String : AnyObject] = [:]
        New["ID"] = self.ID as AnyObject
        New["ProductName"] = self.ProductName as AnyObject
        New["ProductPrice"] = self.ProductPrice as AnyObject
        New["ProductQuantitiy"] = self.ProductQuantitiy as AnyObject
        New["ProductDetails"] = self.ProductDetails as AnyObject
        New["ProductImage"] = self.ProductImage as AnyObject
        New["ProductURL"] = self.ProductURL as AnyObject
        return New
    }
    
    func Upload(){
        guard let id = self.ID else { return }
        Firestore.firestore().collection("Products").document(id).setData(MakeDictionary())
    }
    
//    func Remove(){
//        guard let id = self.ID else { return }
//        Firestore.firestore().collection("Users").document(id).delete()
//    }
    
    
    
    
}


class ProductApi {
    
    
    static func GetProduct(ID : String, completion : @escaping (_ Product : ProductModel)->()){
        
        Firestore.firestore().collection("Products").document(ID).addSnapshotListener { (Snapshot : DocumentSnapshot?, Error : Error?) in
            
            if let data = Snapshot?.data() as [String : AnyObject]? {
                let New = ProductModel(Dictionary: data)
                completion(New)
            }
            
        }
        
    }
    
    static func GetAllProducts(completion : @escaping (_ Product : ProductModel)->()){
        Firestore.firestore().collection("Products").getDocuments { (Snapshot, error) in
            if error != nil { print("Error") ; return }
            guard let documents = Snapshot?.documents else { return }
            for P in documents {
                if let data = P.data() as [String : AnyObject]? {
                    let New = ProductModel(Dictionary: data)
                    completion(New)
                }
            }
        }
        
    }
    
    
    
    
}
