//
//  LoaderPdf.swift
//  MGH1
//
//  Created by abdullah FH on 19/08/1446 AH.
//
import FirebaseFirestore
import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseStorage

struct LoaderPdf : View {
    
    @State var show = false
    
    var body : some View{
        
        Circle()
            .trim(from: 0, to: 0.8)
            .stroke(Color.blue, style: StrokeStyle(lineWidth: 4, lineCap: .round))
            .frame(width: 35, height: 35)
            .rotationEffect(.init(degrees: self.show ? 360 : 0))
            .animation(Animation.default.repeatForever(autoreverses: false).speed(1))
            .padding(40)
            .background(Color.white)
            .cornerRadius(15)
            .onAppear {
                
                self.show.toggle()
        }
    }
}
