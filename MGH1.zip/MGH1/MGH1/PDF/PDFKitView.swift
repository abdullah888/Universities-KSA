//
//  PDFKitView.swift
//  MGH1
//
//  Created by abdullah FH on 18/08/1446 AH.
//

import SwiftUI
import PDFKit
import WebKit

struct PDFKitView: View {
    var product: ProductModel
    var body: some View {
        WebView(request: URLRequest(url: URL(string: product.ProductURL!)!))
    }

}
struct WebView: UIViewRepresentable {
    let request: URLRequest

    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
         uiView.load(request)
    }
}



