//
//  Admin2.swift
//  MGH1
//
//  Created by abdullah FH on 20/08/1446 AH.
//

import FirebaseFirestore
import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseStorage



struct Admin2 : View {
    
    @State var expand = false
    @ObservedObject var data = getData()
    @State var show = false
    @State var type = ""
    @State var isLoading = false
    
    var body : some View{
        
        NavigationView{
            
            ZStack{
                
                Color("Color").edgesIgnoringSafeArea(.all)
                
                ZStack(alignment: .bottomTrailing) {
                    
                    if self.data.data.count != 0{
                        
                        ScrollView(.vertical, showsIndicators: false) {
                            
                            VStack(spacing: 15){
                                
                                ForEach(self.data.data){i in
                                    
                                    CellView(data: i)
                                }
                            }
                            .padding()
                        }
                    }
                    
                    if self.data.isEmpty{
                        
                        GeometryReader{_ in
                            
                            VStack{
                                
                                Text("لا يوجد بيانات")
                                .font(.title)
                                .foregroundColor(.white)
                                .padding()
                            }
                        }
                    }
                    
                    VStack(spacing: 18){
                        
                        
                        if self.expand{
                            
                            Button(action: {
                                
                                self.expand.toggle()
                                self.type = "doc"
                                self.show.toggle()
                                
                            }) {
                                
                                Image(systemName: "doc.fill")
                                    .resizable()
                                    .frame(width: 22, height: 22)
                                    .foregroundColor(.blue)
                                    .padding()
                                
                            }
                            .background(Color.white)
                            .clipShape(Circle())
                            
                            Button(action: {
                                
                                self.expand.toggle()
                                self.type = "img"
                                self.show.toggle()
                                
                            }) {
                                
                                Image(systemName: "photo.fill")
                                    .resizable()
                                    .frame(width: 20, height: 20)
                                    .foregroundColor(.blue)
                                    .padding()
                                
                            }
                            .background(Color.white)
                            .clipShape(Circle())
                        }
                        
                        
                        Button(action: {
                            
                            withAnimation(.spring()){
                                
                                self.expand.toggle()
                            }
                            
                        }) {
                            
                            Image(systemName: self.expand ? "xmark" : "plus")
                                .resizable()
                                .frame(width: 18, height: 18)
                                .foregroundColor(.blue)
                                .padding()
                            
                        }
                        .background(Color.white)
                        .clipShape(Circle())
                    }
                    .padding()
                }
                
                if self.isLoading || (self.data.data.count == 0 && !self.data.isEmpty){
                    
                    GeometryReader{_ in
                        
                        VStack{
                            
                            LoaderPdf()
                        }
                        
                    }.background(Color.black.opacity(0.15).edgesIgnoringSafeArea(.all))
                }
            }
            .navigationBarTitle("Cloud",displayMode: .inline)
            .navigationBarItems(trailing: Button(action: {
                
            }, label: {
                
                VStack{
                    
                    if self.data.data.count != 0 && !self.isLoading{
                        
                        Button(action: {
                            
                            NotificationCenter.default.post(name: NSNotification.Name("Update"), object: nil)
                        }) {
                            
                            Image(systemName: "arrow.clockwise")
                            .resizable()
                            .frame(width: 15, height: 18)
                            .foregroundColor(.blue)
                        }
                    }
                }
            }))
        }
        .sheet(isPresented: self.$show) {
            
            if self.type == "doc"{
                
                DocPicker(show: self.$show)
            }
            else{
                
           //     ImagepdfPicker(show: self.$show)
            }
        }
        .onAppear {
            
            NotificationCenter.default.addObserver(forName: NSNotification.Name("Update"), object: nil, queue: .main) { (_) in
                
                self.data.data.removeAll()
                self.data.isEmpty = false
                self.data.updateData()
            }
        }
    }
}


class getData : ObservableObject{
    
    @Published var data = [Cloud]()
    @Published var isEmpty = false
    
    init() {
        
        updateData()
    }
    
    func updateData(){
        
        let storage = Storage.storage()
        
        storage.reference().child("Cloud Data").listAll { (res, err) in
            
            if err != nil{
                
                print((err?.localizedDescription)!)
                self.isEmpty = true
                return
            }
            
            if res!.items.isEmpty{
                
                self.isEmpty = true
            }
            
            for i in 0..<res!.items.count{
                
                let name = res!.items[i].name
                
                res!.items[i].getMetadata { (meta, err) in
                    
                    if err != nil{
                        
                        print((err?.localizedDescription)!)
                        return
                    }
                    
                    let type = meta?.contentType
                    
                    res!.items[i].downloadURL { (url, err) in
                        
                        if err != nil{
                            
                            print((err?.localizedDescription)!)
                            return
                        }
                        
                        DispatchQueue.main.async {
                            
                            self.data.append(Cloud(id: i, name: name, type: type!, url: "\(url!)"))
                        }
                    }
                }
            }
        }
    }
}

struct Cloud : Identifiable {
    
    var id : Int
    var name : String
    var type : String
    var url : String
}


struct CellView : View {
    
    var data : Cloud
    
    var body : some View{
        
        HStack(spacing: 15){
            
            Image(data.type == "image/jpeg" ? "pic" : "doc")
            .resizable()
            .renderingMode(.original)
            .frame(width: 55, height: 55)
            
            Text(getDate())
                .fontWeight(.bold)
            
            Spacer()
            
        }.padding()
        .background(Color.white)
        .cornerRadius(10)
    }
    
    func getDate()->String{
        
        let format = DateFormatter()
        format.dateFormat = "dd-MM-YYYY hh:mm a"
        return format.string(from: Date(timeIntervalSince1970: TimeInterval.init(Double(data.name)!)))
    }
}
