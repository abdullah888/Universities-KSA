//
//  UploadPdfFile.swift
//  MGH1
//
//  Created by abdullah FH on 21/08/1446 AH.
//

import SwiftUI
import Firebase
import FirebaseAuth

struct UploadPdfFile: View {
   
    @State var DocPicker = false
    var body: some View {
        ZStack{
            VStack {
                
                VStack {
                    Button {
                 
                        self.DocPicker.toggle()
                        
                    } label: {
                        Image("doc")
                            .font(.title)
                            .foregroundColor(.red)
                        
                    } .padding()
                    
                    
                    Button {
                 
                        self.DocPicker.toggle()
                        
                    } label: {
                        Image(systemName: "power")
                            .font(.title)
                            .foregroundColor(.red)
                        
                    } .padding()
                } .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .tag(tabs[2])
                    .background(Color("bg").ignoresSafeArea())
            }
            
        }.sheet(isPresented: $DocPicker) {
            MGH1.DocPicker(show: $DocPicker)
           
        }
 
    }
}

struct UploadPdfFile_Previews: PreviewProvider {
    static var previews: some View {
        UploadPdfFile()
    }
}

  
