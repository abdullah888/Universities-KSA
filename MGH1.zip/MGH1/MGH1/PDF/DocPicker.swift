//
//  DocPicker.swift
//  MGH1
//
//  Created by abdullah FH on 19/08/1446 AH.
//
import FirebaseFirestore
import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseStorage
import MobileCoreServices


struct DocPicker : UIViewControllerRepresentable {

    @Binding var show : Bool
   
    
    func makeCoordinator() -> Coordinator {
        
        return DocPicker.Coordinator(parent1: self)
    }
    
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        
        let picker = UIDocumentPickerViewController(documentTypes: [String(kUTTypeItem)], in: .open)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {
        
        
    }
    
    class Coordinator : NSObject,UIDocumentPickerDelegate{
        
        var parent : DocPicker
        
        init(parent1 : DocPicker) {
            
            parent = parent1
        }
        
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            
            self.parent.show = false
        }
    }
}


