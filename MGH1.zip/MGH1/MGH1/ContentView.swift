//
//  ContentView.swift
//  MGH1
//
//  Created by abdullah FH on 18/08/1446 AH.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Cech()
    }
}

#Preview {
    ContentView()
}
