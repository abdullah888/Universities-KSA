//
//  ProfileViewModel.swift
//  Project001app
//
//  Created by abdullah FH on 07/05/1446 AH.
//

import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore
class ProfileViewModel : ObservableObject{
 
    //Modell
    @Published var user: [UserModel] = []
    @Published  var Name = ""
    @Published var Phonenumber = ""
    @Published var userInfo = UserModel(ID: "", Name: "", Phonenumber: "", Image: "")
    @AppStorage("current_status") var status = false
    
    // Image Picker For Updating Image...
    @Published var picker = false
    @Published var img_Data = Data(count: 0)
    // Loading View..
    @Published var isLoading = false
    
    let ref = Firestore.firestore()
    let uiD = Auth.auth().currentUser?.uid
    
    init() {
        fetchUserData()
        GeUsers()
        Auth.auth().addStateDidChangeListener { auth, user in
            if let id = user?.uid{
            UserApi.GetUser(ID: id) { User in
                DispatchQueue.main.async {
                    self.userInfo = User
                }
               }
            }
        }
      
    }
    
    
    func logOut(){
        
        // logging out..
        DispatchQueue.main.async {
            try! Auth.auth().signOut()
            self.status = false
        }
    }
    
    

    
    
   // خاص بالرفع مع الصور
    func updateImage(){
        
        isLoading = true
        Auth.auth().addStateDidChangeListener { auth, user in
            UploadImage(imageData: self.img_Data, path: "User_Image") { (url) in
            
            self.ref.collection("Users").document(user!.uid).updateData([
            
                "UserImage": url,
            ]) { [self] (err) in
                if err != nil{return}
                
                // Updating View..
                self.isLoading = false
                UserApi.GetUser(ID: user!.uid) { User in
                    DispatchQueue.main.async {
                        self.userInfo = User
                    }
                   }
                }
            }
        }
    }
   
    func GeUsers(){
        Auth.auth().addStateDidChangeListener { auth, user in
            if let userid = user?.uid{
                UserApi.GetUser(ID: userid) { User in
                    DispatchQueue.main.async {
                        self.user.append(User)
                    }
                   
                }
            }
            
        }
    }
    
    func fetchUserData(){
        
        let db = Firestore.firestore()
        
        db.collection("Users").getDocuments { (snap, err) in
            
            guard let productData = snap else{return}
            
            self.user = productData.documents.compactMap({ (doc) -> UserModel? in
               
                let ID = doc.documentID
                let Name = doc.get("Name") as! String
                let Phonenumber = doc.get("Phonenumber") as! String
                let Image = doc.get("Image") as! String
                return UserModel(ID: ID, Name: Name, Phonenumber: Phonenumber, Image: Image)
               
           
                
            })
            DispatchQueue.main.async {
                self.user = self.user
            }
        }
    }
    
    func deleteUser(id: String){
        let ref = Firestore.firestore()
        DispatchQueue.main.async {
            ref.collection("Users").document(id).delete { (err) in
                if err != nil{
                    print(err!.localizedDescription)
                    return
                }
            }
        }
    }
    func Delete(){
        user.forEach { (i) in
            DispatchQueue.main.async {
                self.deleteUser(id: i.ID!)
            }
        }
    }

}





// code


//func login(){
//
//    Auth.auth().signInAnonymously { (res, err) in
//
//        if err != nil{
//            print(err!.localizedDescription)
//            return
//        }
//
//        print("Success = \(res!.user.uid)")
//
//        // After Logging in Fetching Data
//
////            self.fetchData()
//    }
//}
