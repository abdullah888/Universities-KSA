//
//  ProductViewModel.swift
//  Project001app
//
//  Created by abdullah FH on 12/05/1446 AH.
//

import SwiftUI
import Firebase


class ProductViewModel :ObservableObject{
    
   
    /*  // for add documentID
     let ref = firestore.collection(myCollection).document()
     // ref is a DocumentReference
     let id = ref.documentID
     */
   
    // PeoductObject
    @Published var Filtered: [ProductModel] = []
    @Published var products: [ProductModel] = []
    @Published var Productdatas = [ProductModel]()
    @Published var search = ""
    // product
//    @Published var ProductName = ""
//    @Published var description = ""
//    @Published var description = ""
//    @Published var description = ""
//    // Image Picker...
//    @Published var picker = false
//    @Published var img_Data = Data(count: 0)
//    @Published var isLoading = false
    
    let ref = Firestore.firestore()
    
    init(){
      //  Udateee()
       // GetProduct()
    // GetAllProduct()
       fetchData()
    }
   
    
//    func UploadProduct(){
//        let db = Firestore.firestore()
//        Auth.auth().addStateDidChangeListener { auth, user in
//        UploadImage(imageData: self.img_Data, path: "Products_Image") { url in
//            db.collection("Products")
//                .document()
//                .setData(["name":self.name,"description":self.description,"image":url]) { (err) in
//                    if err != nil{
//                        print((err?.localizedDescription)!)
//                        return
//                    }
//                }
//            }
//        }
//    }
 
    func Udateee() {
        ProductApi.GetAllProducts { (products) in
            ProductApi.GetProduct(ID: products.ID!) { (product) in
                self.products.append(product)
            }
        }
    }
   
    
    func GetAllProduct(){
        
        let db = Firestore.firestore()
       
            db.collection("Products").addSnapshotListener { (snap, err) in
                
                if err != nil{
                    
                    print((err?.localizedDescription)!)
                    return
                }
                
                for i in snap!.documentChanges{
                    
                    let ID = i.document.documentID
                    let ProductName = i.document.get("ProductName") as! String
                    let ProductPrice = i.document.get("ProductPrice") as! Double
                    let ProductQuantitiy = i.document.get("ProductQuantitiy") as! Int
                    let ProductDetails = i.document.get("ProductDetails") as! String
                    let ProductImage = i.document.get("ProductImage") as! String
                    let ProductURL = i.document.get("ProductURL") as! String
                    DispatchQueue.main.async {
                        self.products.append(ProductModel(ID: ID, ProductName: ProductName, ProductPrice: ProductPrice, ProductQuantitiy: ProductQuantitiy, ProductDetails: ProductDetails, ProductImage: ProductImage, ProductURL: ProductURL))
                }
           }
                
        }
    }
    
    //اضف الكود السريع وحط الاصافة من الهوم
    func GetProduct(){
        ref.collection("Products").addSnapshotListener { snap, err in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
            guard let data = snap else{return}

            data.documentChanges.forEach { (doc) in
                if doc.type == .added{
                    ProductApi.GetAllProducts { Product in
                        ProductApi.GetProduct(ID: Product.ID!) { Product in
                            //her
                        }
                    }
         
                }
            }
        }
    }
    

    
    func fetchData(){
        
        let db = Firestore.firestore()
        
        db.collection("Products").getDocuments { (snap, err) in
            
            guard let productData = snap else{return}
            
            self.products = productData.documents.compactMap({ (doc) -> ProductModel? in
                
                let id = doc.documentID
                let ProductName = doc.get("ProductName") as! String
                let ProductPrice = doc.get("ProductPrice") as! Double
                let ProductQuantitiy = doc.get("ProductQuantitiy") as! Int
                let ProductDetails = doc.get("ProductDetails") as! String
                let ProductImage = doc.get("ProductImage") as! String
                let ProductURL = doc.get("ProductURL") as! String
                return ProductModel(ID: id, ProductName: ProductName, ProductPrice: ProductPrice, ProductQuantitiy: ProductQuantitiy, ProductDetails: ProductDetails, ProductImage: ProductImage, ProductURL: ProductURL)
       
            })
            DispatchQueue.main.async {
                self.Filtered = self.products
            }
        }
    }
    
   
    
    func deleteCollection(collection: String) {
      
        let db = Firestore.firestore()
           db.collection(collection).getDocuments() { (querySnapshot, err) in
               if let err = err {
                   print("Error getting documents: \(err)")
                   return
               }

               for document in querySnapshot!.documents {
                   print("Deleting \(document.documentID) => \(document.data())")
                   DispatchQueue.main.async {
                       document.reference.delete()
                   }
               }
           }
       }
    

    
    func calculateProductTotalPrice()->String{
        
        var price : Float = 0
        
        Productdatas.forEach { (product) in
            price += Float(truncating: product.ProductQuantitiy! as NSNumber) * Float(truncating: product.ProductPrice! as NSNumber)
        }
        
        return getPrice(value: price)
    }
    
    func getPrice(value: Float)->String{
        
        let format = NumberFormatter()
        format.numberStyle = .currency
        format.currencySymbol = "SR"
        return format.string(from: NSNumber(value: value)) ?? ""
    }
  
    

//    func addtoCart(){
//        let db = Firestore.firestore()
//        let id = Auth.auth().currentUser?.uid
//        Productdatas.forEach { (product) in
//        db.collection("Carts")
//            .document(id!)
//            .setData(["UserID":id!,
//                      "CartName":product.ProductName!,
//                      "CartPrice":product.ProductPrice!,
//                      "CartQuantitiy":product.ProductQuantitiy!,
//                      "CartDetails":product.ProductDetails!,
//                      "CartImage":product.ProductImage!,
//                      "CartID":product.ID!,
//                      
//            ]) { (err) in
//                
//                if err != nil{
//                    
//                    print((err?.localizedDescription)!)
//                    return
//                }
//                
//                // it will dismiss the recently presented modal....
//                
//            }
//            
//        }
//    }
    
    // Search or Filter...
    
    func filterData(){
        withAnimation(.linear){
            self.Filtered = self.products.filter{
                return $0.ProductName!.lowercased().contains(self.search.lowercased())
            }
        }
    }
    
    
    // deleting Cart...
    
    func reset() {
    DispatchQueue.main.async {
        for i in 0..<self.Productdatas.count {
            self.Productdatas[i].ProductQuantitiy = 0
        }
        DispatchQueue.main.async {
            self.Productdatas.removeAll()
        }
    }
}
    
    func deletingProduct(id: String){
        let ref = Firestore.firestore()
        DispatchQueue.main.async {
            ref.collection("Products").document(id).delete { (err) in
                if err != nil{
                    print(err!.localizedDescription)
                    return
                }
            }
        }
    }
    func Delete(){
        products.forEach { (i) in
            DispatchQueue.main.async {
                self.deletingProduct(id: i.ID!)
            }
        }
    }
  
      
}










